#include <bits/stdc++.h>

using namespace std;

int main(){
    string nums;

    while (getline(cin, nums)){
        stringstream ss(nums);

        vector<int> vec;
        long long int aux;
        while (ss >> aux){
            vec.push_back(aux);
        }

        while (!is_sorted(vec.begin(), vec.end())){
            for(int i = vec.size() -2; i >= 0; i--){
                if (vec[i+1] > vec[i]){
                    cout << i+1 << " ";
                    reverse(vec.begin()+vec.size()-1-i, vec.end());
                    break;
                }
            }
        }
        cout << "0" << endl;

    }
}